import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CandidateService {

  constructor(private httpClient: HttpClient) {}

  public insertCandidate(formData){
    const headers = new HttpHeaders({
      // 'Content-Type': 'application/x-www-form-urlencoded'
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });

    var body = JSON.stringify({

    "name": formData.get('name').value, 
    "contactNo": formData.get('contactNo').value,
    "address": formData.get('address').value,
    "userName": formData.get('userName').value,
    "password": formData.get('password').value,
    "email": formData.get('email').value,
    "role":formData.get('role').value,

    "primarySkils":formData.get('primarySkils').value,
    "secondarySkils":formData.get('secondarySkils').value,
    "experience":formData.get('experience').value,
    "qualification":formData.get('qualification').value,
    "designation":formData.get('designation').value,
    "noticePeriod":formData.get('noticePeriod').value,
    "location":formData.get('location').value,
    "status":formData.get('status').value

     })
    
    this.httpClient.post('http://localhost:11084/addCandidate', body, { headers: headers }).subscribe(
      response => {
        console.log(response);
      },
      error => {
        console.log(error);
      });
  }
}
